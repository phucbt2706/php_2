<?php
namespace App\Model;

class Model {
    public function __construct(){
        echo "This is Model";
    }
}