<?php
namespace App\Controller;

class Controller {
    public function __construct(){
        echo "This is Controller <br>";
    }
}