<?php
require_once __DIR__."/vendor/autoload.php";

use App\Controller\Controller;
use App\Model\Model;

$controller = new Controller();
$model = new Model();
